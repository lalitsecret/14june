[
	{...product,...user,qty:3,id:cart.length+1}
	{...product,...user,qty:1}
]