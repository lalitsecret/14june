import React from 'react'
import Filters from './Filters'
import Products from './Products'
function App()
{
	
	return <div className="right">
		<Filters/>
		<Products/>
	</div>
}
export default App