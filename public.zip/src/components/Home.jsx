import React from 'react'
import Left from './Left'
import Right from './Right'
function App()
{
	
	return <main>
		<Left/>
		<Right/>
	</main>
}
export default App