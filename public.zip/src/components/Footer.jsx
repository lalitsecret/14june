import React from 'react'
function App()
{
	
	return <footer>ecomemrce panel on redux and react</footer>
}
export default App