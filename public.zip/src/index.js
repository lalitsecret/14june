import React from 'react';
import ReactDOM from 'react-dom';
import Main from './redux/Main'
import './css/style.css'
ReactDOM.render(<Main/>,document.getElementById('root'));
